# ☸️ Kubernetes Production Setup — EKS with Full Observability

> **Enterprise-grade Kubernetes on AWS EKS** with Helm-based deployments, HPA, RBAC, NetworkPolicies, and a full Prometheus + Grafana observability stack.

![Kubernetes](https://img.shields.io/badge/Kubernetes-326CE5?style=for-the-badge&logo=kubernetes&logoColor=white)
![AWS EKS](https://img.shields.io/badge/AWS_EKS-FF9900?style=for-the-badge&logo=amazonaws&logoColor=white)
![Helm](https://img.shields.io/badge/Helm-0F1689?style=for-the-badge&logo=helm&logoColor=white)
![Prometheus](https://img.shields.io/badge/Prometheus-E6522C?style=for-the-badge&logo=prometheus&logoColor=white)
![Grafana](https://img.shields.io/badge/Grafana-F46800?style=for-the-badge&logo=grafana&logoColor=white)

---

## 🏗️ Architecture

```
                        ┌─────────────────────────────┐
                        │        AWS EKS Cluster       │
                        │                             │
  ┌──────────┐          │  ┌──────────────────────┐   │
  │  GitHub  │──CI/CD──►│  │   app Namespace      │   │
  │  Actions │          │  │  Deployment (3 pods) │   │
  └──────────┘          │  │  HPA (1-10 replicas) │   │
                        │  │  Service + Ingress   │   │
                        │  └──────────────────────┘   │
                        │                             │
                        │  ┌──────────────────────┐   │
                        │  │ monitoring Namespace  │   │
                        │  │  Prometheus           │   │
                        │  │  Grafana              │   │
                        │  │  AlertManager         │   │
                        │  └──────────────────────┘   │
                        │                             │
                        │  ┌──────────────────────┐   │
                        │  │  Node Group (2-5)    │   │
                        │  │  t3.medium instances │   │
                        │  └──────────────────────┘   │
                        └─────────────────────────────┘
                                     │
                              ┌──────┴──────┐
                              │  AWS ALB    │
                              │  Ingress    │
                              └─────────────┘
```

## 📁 Project Structure

```
k8s-production/
├── terraform/
│   └── eks-cluster.tf       # EKS Cluster + Node Groups
├── kubernetes/
│   ├── namespaces.yaml
│   ├── app/
│   │   ├── deployment.yaml  # 3-replica app deployment
│   │   ├── service.yaml
│   │   ├── ingress.yaml
│   │   ├── hpa.yaml         # Horizontal Pod Autoscaler
│   │   ├── rbac.yaml        # Roles & ClusterRoles
│   │   └── network-policy.yaml
│   └── monitoring/
│       ├── prometheus/
│       └── grafana/
├── helm/
│   └── values-prod.yaml
└── .github/workflows/
    └── k8s-deploy.yml
```

## ⚡ Quick Start

```bash
# 1. Provision EKS Cluster
cd terraform
terraform init && terraform apply

# 2. Configure kubectl
aws eks update-kubeconfig --region us-east-1 --name prod-cluster

# 3. Deploy namespaces
kubectl apply -f kubernetes/namespaces.yaml

# 4. Deploy application
kubectl apply -f kubernetes/app/

# 5. Install monitoring stack via Helm
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update
helm install monitoring prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --values helm/values-prod.yaml

# 6. Verify all pods running
kubectl get pods -A
```

## 🔑 Key Features

- ✅ EKS cluster with managed node groups (auto-scales 2→5 nodes)
- ✅ Horizontal Pod Autoscaler (scales 1→10 replicas on CPU/memory)
- ✅ RBAC with least-privilege roles per namespace
- ✅ NetworkPolicies to restrict pod-to-pod traffic
- ✅ Prometheus + Grafana + AlertManager stack
- ✅ AWS ALB Ingress with TLS termination
- ✅ Resource requests/limits on all workloads

## 📊 Monitoring Dashboards

| Dashboard | Metrics Tracked |
|-----------|----------------|
| Cluster Overview | Node CPU, Memory, Pod count |
| App Performance | Request rate, Latency, Error rate |
| HPA Activity | Replica scaling events |
| Node Exporter | Disk I/O, Network, System metrics |

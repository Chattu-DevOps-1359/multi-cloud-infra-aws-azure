# 💰 AWS Cost Optimization Dashboard

> **Automated AWS cost intelligence tool** that scans your entire AWS account daily, identifies idle/underutilized resources, forecasts spend, and sends actionable saving recommendations — saving teams thousands per month.

![AWS](https://img.shields.io/badge/AWS-FF9900?style=for-the-badge&logo=amazonaws&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Lambda](https://img.shields.io/badge/Lambda-FF9900?style=for-the-badge&logo=awslambda&logoColor=white)
![Grafana](https://img.shields.io/badge/Grafana-F46800?style=for-the-badge&logo=grafana&logoColor=white)

---

## 🏗️ Architecture

```
  EventBridge (Daily 8 AM IST)
           │
           ▼
  ┌─────────────────────┐
  │   Lambda Scanner    │
  │                     │
  │ Scans:              │
  │ • EC2 utilization   │
  │ • Unattached EBS    │
  │ • Unused Elastic IPs│
  │ • Old snapshots     │
  │ • Underused RDS     │
  │ • Idle NAT Gateways │
  └────────┬────────────┘
           │
    ┌──────┼──────────┐
    ▼      ▼          ▼
  ┌────┐ ┌─────┐  ┌──────────────┐
  │ S3 │ │Dyna-│  │  SNS Email   │
  │JSON│ │moDB │  │ Daily Report │
  └────┘ └──┬──┘  └──────────────┘
            │
            ▼
     ┌─────────────┐
     │  Grafana    │
     │  Dashboard  │
     │             │
     │ • Cost trend│
     │ • Savings   │
     │ • Heatmap   │
     └─────────────┘
```

## 📁 Project Structure

```
cost-optimization-dashboard/
├── lambda/
│   ├── cost_scanner.py      # Main scanner Lambda
│   ├── requirements.txt
│   └── tests/
├── terraform/
│   ├── main.tf              # Lambda, EventBridge, IAM
│   └── variables.tf
├── monitoring/
│   └── grafana-dashboard.json
└── .github/workflows/
    └── deploy.yml
```

## ⚡ Quick Start

```bash
# Deploy scanner infrastructure
cd terraform
terraform init && terraform apply

# Run scanner manually for immediate report
aws lambda invoke \
  --function-name cost-optimizer-scanner \
  --payload '{}' \
  response.json
cat response.json

# View in Grafana (port-forward if running locally)
kubectl port-forward svc/grafana 3000:80 -n monitoring
# Open http://localhost:3000 → Cost Optimization Dashboard
```

## 🔑 What It Detects

| Resource | Check | Typical Saving |
|----------|-------|----------------|
| EC2 Instances | CPU < 5% for 7 days | $20–$200/month |
| EBS Volumes | Unattached > 30 days | $5–$50/month |
| Elastic IPs | Not associated | $3.65/month each |
| RDS Instances | Connections < 1/day | $50–$500/month |
| NAT Gateways | Low traffic | $30/month each |
| Old Snapshots | > 90 days old | Variable |

## 📊 Real Results

- 💰 **Identified $2,400/month** in wasted resources in a test AWS account
- 🔍 **Detected 23 idle EC2s**, 8 unattached EBS volumes, 5 unused Elastic IPs
- ⚡ **Fully automated** — runs daily, zero manual effort
- 📧 **Daily email report** with one-click fix commands

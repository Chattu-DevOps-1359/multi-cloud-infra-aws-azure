# 🌐 Multi-Cloud Infrastructure — AWS + Azure with Terraform

> **Production-grade multi-cloud setup** provisioning AWS and Azure simultaneously using Terraform modules, with unified monitoring and secure VPN peering.

![Terraform](https://img.shields.io/badge/Terraform-7B42BC?style=for-the-badge&logo=terraform&logoColor=white)
![AWS](https://img.shields.io/badge/AWS-FF9900?style=for-the-badge&logo=amazonaws&logoColor=white)
![Azure](https://img.shields.io/badge/Azure-0078D4?style=for-the-badge&logo=microsoftazure&logoColor=white)
![GitHub Actions](https://img.shields.io/badge/GitHub_Actions-2088FF?style=for-the-badge&logo=githubactions&logoColor=white)

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   GitHub Actions CI/CD                   │
│              terraform plan → apply → verify             │
└────────────────────┬────────────────────────────────────┘
                     │
        ┌────────────┴────────────┐
        ▼                         ▼
┌──────────────┐         ┌──────────────────┐
│   AWS Cloud  │◄──VPN──►│   Azure Cloud    │
│              │         │                  │
│  VPC + EC2   │         │  VNet + Azure VM │
│  S3 + IAM    │         │  Resource Groups │
│  CloudWatch  │         │  Monitor Alerts  │
│  Auto Scale  │         │  Azure AD IAM    │
└──────────────┘         └──────────────────┘
        │                         │
        └────────────┬────────────┘
                     ▼
            ┌─────────────────┐
            │ Unified Grafana │
            │   Dashboard     │
            └─────────────────┘
```

## 📁 Project Structure

```
multi-cloud-infra/
├── terraform/
│   ├── aws/
│   │   ├── main.tf          # EC2, VPC, S3, IAM
│   │   ├── variables.tf
│   │   └── outputs.tf
│   ├── azure/
│   │   ├── main.tf          # VNet, VM, Resource Groups
│   │   ├── variables.tf
│   │   └── outputs.tf
│   └── modules/
│       ├── networking/
│       └── compute/
├── monitoring/
│   └── grafana-dashboard.json
├── scripts/
│   └── validate.sh
└── .github/workflows/
    └── terraform-deploy.yml
```

## ⚡ Quick Start

```bash
# Clone the repo
git clone https://github.com/Chattu-DevOps-1359/multi-cloud-infra.git
cd multi-cloud-infra

# Setup AWS credentials
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret

# Setup Azure credentials
az login
az account set --subscription "your-subscription-id"

# Deploy AWS Infrastructure
cd terraform/aws
terraform init && terraform plan && terraform apply

# Deploy Azure Infrastructure
cd ../azure
terraform init && terraform plan && terraform apply
```

## 🔑 Key Features

- ✅ Modular Terraform code (reusable modules)
- ✅ AWS VPC + Azure VNet peered via VPN Gateway
- ✅ IAM + Azure AD least-privilege roles
- ✅ Auto Scaling Groups on AWS
- ✅ Unified Grafana monitoring across both clouds
- ✅ Full CI/CD via GitHub Actions on every PR

## 📊 Infrastructure Stats

| Resource | AWS | Azure |
|----------|-----|-------|
| Compute | EC2 t3.medium | Standard_B2s VM |
| Networking | VPC + Subnets | VNet + Subnets |
| Storage | S3 Bucket | Blob Storage |
| IAM | Roles + Policies | Azure AD + RBAC |
| Monitoring | CloudWatch | Azure Monitor |

# ⚡ Serverless Image Processing Pipeline — AWS Lambda + S3 + SNS

> **Event-driven serverless pipeline** that auto-processes images uploaded to S3, generates thumbnails, extracts metadata, and sends alerts via SNS — all with zero servers to manage.

![AWS Lambda](https://img.shields.io/badge/AWS_Lambda-FF9900?style=for-the-badge&logo=awslambda&logoColor=white)
![S3](https://img.shields.io/badge/Amazon_S3-569A31?style=for-the-badge&logo=amazons3&logoColor=white)
![Terraform](https://img.shields.io/badge/Terraform-7B42BC?style=for-the-badge&logo=terraform&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)

---

## 🏗️ Architecture

```
  User/App
     │
     ▼ Upload image
┌─────────┐    S3 Event     ┌────────────────┐
│  S3     │────Trigger────►│ Lambda          │
│ (input) │                │ image-processor │
└─────────┘                │                │
                           │ 1. Resize image │
                           │ 2. Extract EXIF │
                           │ 3. Save thumb  │
                           └───────┬────────┘
                                   │
                    ┌──────────────┼──────────────┐
                    ▼              ▼               ▼
              ┌──────────┐  ┌──────────┐  ┌──────────────┐
              │ S3       │  │ DynamoDB │  │ SNS Topic    │
              │(output/  │  │(metadata │  │(alert email) │
              │ thumbs)  │  │  store)  │  └──────────────┘
              └──────────┘  └──────────┘
                                   │
                            ┌──────────────┐
                            │ CloudWatch   │
                            │ Logs+Metrics │
                            └──────────────┘
```

## 📁 Project Structure

```
serverless-image-pipeline/
├── lambda/
│   ├── image_processor.py   # Main Lambda handler
│   ├── requirements.txt
│   └── tests/
│       └── test_handler.py
├── terraform/
│   ├── main.tf              # Lambda, S3, DynamoDB, SNS, IAM
│   ├── variables.tf
│   └── outputs.tf
└── .github/workflows/
    └── deploy-lambda.yml
```

## ⚡ Quick Start

```bash
# 1. Install dependencies
cd lambda
pip install -r requirements.txt -t ./package/

# 2. Deploy infrastructure
cd ../terraform
terraform init && terraform apply

# 3. Test by uploading an image
aws s3 cp test-image.jpg s3://$(terraform output -raw input_bucket)/

# 4. Check output
aws s3 ls s3://$(terraform output -raw output_bucket)/thumbnails/

# 5. View logs
aws logs tail /aws/lambda/image-processor --follow
```

## 🔑 Key Features

- ✅ Auto-triggered on S3 upload (event-driven, zero polling)
- ✅ Generates 3 thumbnail sizes: 150px, 300px, 800px
- ✅ Extracts EXIF metadata and stores in DynamoDB
- ✅ SNS email alert on processing failure
- ✅ Dead Letter Queue (DLQ) for failed events
- ✅ X-Ray tracing enabled for end-to-end visibility
- ✅ Fully provisioned by Terraform (IaC)
- ✅ 99.9% cost reduction vs always-on EC2

## 💰 Cost Comparison

| Approach | Monthly Cost (1M images) |
|----------|--------------------------|
| EC2 (always-on) | ~$70/month |
| **Lambda (serverless)** | **~$0.20/month** |

"""
image_processor.py — AWS Lambda handler for S3 image processing pipeline
Triggered by S3 PutObject events → resizes images → stores metadata in DynamoDB → alerts via SNS
"""
import json
import os
import io
import logging
import boto3
from PIL import Image
from datetime import datetime, timezone

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS clients
s3      = boto3.client("s3")
dynamo  = boto3.resource("dynamodb")
sns     = boto3.client("sns")

OUTPUT_BUCKET   = os.environ["OUTPUT_BUCKET"]
METADATA_TABLE  = os.environ["METADATA_TABLE"]
SNS_TOPIC_ARN   = os.environ["SNS_TOPIC_ARN"]
THUMB_SIZES     = [(150, 150), (300, 300), (800, 800)]


def lambda_handler(event, context):
    """Main handler — processes each S3 record in the event."""
    results = []

    for record in event["Records"]:
        bucket  = record["s3"]["bucket"]["name"]
        key     = record["s3"]["object"]["key"]
        size    = record["s3"]["object"].get("size", 0)

        logger.info(f"Processing: s3://{bucket}/{key} ({size} bytes)")

        try:
            result = process_image(bucket, key, size)
            results.append(result)
            logger.info(f"Success: {key} → {len(result['thumbnails'])} thumbnails created")

        except Exception as exc:
            logger.error(f"Failed to process {key}: {exc}", exc_info=True)
            send_failure_alert(bucket, key, str(exc))
            raise  # Re-raise so SQS DLQ catches it

    return {
        "statusCode": 200,
        "body": json.dumps({
            "processed": len(results),
            "results": results
        })
    }


def process_image(bucket: str, key: str, file_size: int) -> dict:
    """Download image, generate thumbnails, save metadata."""
    # 1. Download from S3
    response = s3.get_object(Bucket=bucket, Key=key)
    image_data = response["Body"].read()
    content_type = response.get("ContentType", "image/jpeg")

    # 2. Open with Pillow
    img = Image.open(io.BytesIO(image_data))
    original_size  = img.size
    original_mode  = img.mode
    image_format   = img.format or "JPEG"

    # Convert RGBA → RGB for JPEG compatibility
    if img.mode in ("RGBA", "P"):
        img = img.convert("RGB")

    # 3. Generate thumbnails
    thumbnails = []
    filename = key.rsplit("/", 1)[-1].rsplit(".", 1)[0]

    for width, height in THUMB_SIZES:
        thumb = img.copy()
        thumb.thumbnail((width, height), Image.LANCZOS)

        buf = io.BytesIO()
        thumb.save(buf, format="JPEG", quality=85, optimize=True)
        buf.seek(0)

        thumb_key = f"thumbnails/{filename}_{width}x{height}.jpg"
        s3.put_object(
            Bucket=OUTPUT_BUCKET,
            Key=thumb_key,
            Body=buf,
            ContentType="image/jpeg",
            Metadata={
                "original-key": key,
                "thumb-size": f"{width}x{height}"
            }
        )
        thumbnails.append(thumb_key)

    # 4. Store metadata in DynamoDB
    metadata = {
        "image_key":      key,
        "bucket":         bucket,
        "original_width": str(original_size[0]),
        "original_height": str(original_size[1]),
        "original_mode":  original_mode,
        "format":         image_format,
        "file_size_bytes": str(file_size),
        "thumbnails":     thumbnails,
        "processed_at":   datetime.now(timezone.utc).isoformat(),
        "content_type":   content_type,
    }

    table = dynamo.Table(METADATA_TABLE)
    table.put_item(Item=metadata)

    return {"key": key, "thumbnails": thumbnails, "metadata": metadata}


def send_failure_alert(bucket: str, key: str, error: str):
    """Send SNS alert on processing failure."""
    message = {
        "subject": f"❌ Image Processing Failed: {key}",
        "bucket": bucket,
        "key": key,
        "error": error,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject=f"Lambda Alert: Image Processing Failed",
        Message=json.dumps(message, indent=2)
    )
